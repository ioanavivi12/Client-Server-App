#pragma once
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <bits/stdc++.h>
#include <netinet/tcp.h>
#include <libexplain/connect.h>
#include <errno.h>

const char *explain_connect(int fildes, const struct sockaddr *serv_addr, int serv_addr_size);

#define MAX_CLIENTS 2000
#define MAX_LEN 1500
#define MAX_TOPICS 50

#define connect_format "New client %s connected from %s : %d\n"
#define exit_format "Client %s disconnected.\n"
#define allready_connected_format "Client %s already connected.\n"
#define message_format "%s:%d - %s - "

/**
 * Structura pentru un mesaj primit de la un client UIDP
*/
typedef struct {
    char topic[MAX_TOPICS];
    uint8_t type;
    char payload[MAX_LEN];
} message;

/**
 * Structura pentru un mesaj trimis de server unui client TCP
*/
typedef struct {
    char ip_client_udp[MAX_TOPICS];
    int port_client_udp;
    message msg;
} udp_message;

#define DIE(assertion, call_description)                                       \
  do {                                                                         \
    if (assertion) {                                                           \
      fprintf(stderr, "(%s, %d): ", __FILE__, __LINE__);                       \
      perror(call_description);                                                \
      exit(EXIT_FAILURE);                                                      \
    }                                                                          \
  } while (0)

int run_client(int tcpfd, char *id);
int run_all_clients(int tcpfd, int udpfd);
message create_message(char *topic, uint8_t data, char *payload);
int send_all(int sockfd, void *buffer, size_t len);
int recv_all(int sockfd, void *buffer, size_t len);
udp_message create_udp_message(char *ip_client_udp, int port_client_udp, message msg);
